#!/bin/sh
set -eu

WARN="${PVC_USAGE_WARN_PERCENT:-80}"

echo "Checking PVCs and pods related to Langfuse..."

kubectl get pvc -A | grep -E "langfuse|postgres|clickhouse|redis|minio" || true

echo ""
echo "Checking pod filesystem usage where possible..."

for ns in langfuse langfuse-management; do
  pods=$(kubectl get pods -n "$ns" --no-headers 2>/dev/null | awk '{print $1}' || true)

  for pod in $pods; do
    echo ""
    echo "Pod: $ns/$pod"
    kubectl exec -n "$ns" "$pod" -- sh -c "df -h 2>/dev/null || true" 2>/dev/null || true
  done
done

echo ""
echo "WARN threshold configured as ${WARN}%."
echo "This script currently logs usage. Integrate with Prometheus/Alertmanager for real alerts."
