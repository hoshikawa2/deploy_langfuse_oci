import os
import redis

def env(name, default=None):
    value = os.getenv(name, default)
    if value is None:
        raise RuntimeError(f"Missing env var: {name}")
    return value

r = redis.Redis(
    host=env("REDIS_HOST"),
    port=int(env("REDIS_PORT", "6379")),
    password=os.getenv("REDIS_PASSWORD"),
    decode_responses=True,
)

info_memory = r.info("memory")
info_stats = r.info("stats")
info_keyspace = r.info("keyspace")

print("\n=== REDIS MEMORY ===")
for k in [
    "used_memory_human",
    "used_memory_peak_human",
    "mem_fragmentation_ratio",
]:
    print(f"{k}: {info_memory.get(k)}")

print("\n=== REDIS STATS ===")
for k in [
    "evicted_keys",
    "expired_keys",
    "keyspace_hits",
    "keyspace_misses",
]:
    print(f"{k}: {info_stats.get(k)}")

print("\n=== KEYSPACE ===")
for db, value in info_keyspace.items():
    print(f"{db}: {value}")

print("\n=== SAMPLE KEYS WITHOUT TTL ===")
count = 0

for key in r.scan_iter(count=1000):
    ttl = r.ttl(key)

    if ttl == -1:
        print(f"NO TTL: {key}")
        count += 1

    if count >= 20:
        break

print("\nRedis monitoring finished.")
