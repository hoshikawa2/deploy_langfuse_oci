import os
import redis

def env(name, default=None):
    value = os.getenv(name, default)
    if value is None:
        raise RuntimeError(f"Missing env var: {name}")
    return value

DRY_RUN = env("DRY_RUN", "true").lower() == "true"

PREFIXES = [
    "temp:",
    "stream:",
    "workflow:",
    "retry:",
]

r = redis.Redis(
    host=env("REDIS_HOST"),
    port=int(env("REDIS_PORT", "6379")),
    password=os.getenv("REDIS_PASSWORD"),
    decode_responses=True,
)

deleted = 0

for prefix in PREFIXES:
    print(f"\nScanning prefix: {prefix}")

    for key in r.scan_iter(match=f"{prefix}*"):
        ttl = r.ttl(key)

        if ttl == -1:
            print(f"Key without TTL: {key}")

            if not DRY_RUN:
                r.expire(key, 3600)

        if "stale" in key:
            print(f"Deleting stale key: {key}")

            if not DRY_RUN:
                r.delete(key)
                deleted += 1

print(f"\nDeleted keys: {deleted}")
