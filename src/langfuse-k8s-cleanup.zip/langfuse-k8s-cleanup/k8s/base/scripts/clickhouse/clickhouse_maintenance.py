import os
import requests

def env(name, default=None):
    value = os.getenv(name, default)
    if value is None:
        raise RuntimeError(f"Missing required env var: {name}")
    return value

DRY_RUN = env("DRY_RUN", "true").lower() == "true"
RULES_RAW = env("CLICKHOUSE_TTL_RULES", "")
DATABASE = env("CLICKHOUSE_DATABASE", "default")

def parse_rules(raw: str):
    rules = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        table, date_column, retention_days = [x.strip() for x in line.split("|")]
        rules.append({
            "table": table,
            "date_column": date_column,
            "retention_days": int(retention_days),
        })
    return rules

def clickhouse_query(query: str):
    url = f"http://{env('CLICKHOUSE_HOST')}:{env('CLICKHOUSE_PORT', '8123')}/"
    auth = (env("CLICKHOUSE_USER", "default"), env("CLICKHOUSE_PASSWORD", ""))
    response = requests.post(url, params={"database": DATABASE}, data=query.encode("utf-8"), auth=auth, timeout=60)
    response.raise_for_status()
    return response.text

def table_exists(table_name: str):
    query = f"""
    SELECT count()
    FROM system.tables
    WHERE database = '{DATABASE}'
      AND name = '{table_name}'
    """
    result = clickhouse_query(query).strip()
    return result == "1"

def main():
    rules = parse_rules(RULES_RAW)
    if not rules:
        print("No CLICKHOUSE_TTL_RULES configured.")
        return

    for rule in rules:
        table = rule["table"]
        date_column = rule["date_column"]
        retention_days = rule["retention_days"]

        print(f"\nRule: table={table}, column={date_column}, retention={retention_days} days")

        if not table_exists(table):
            print(f"SKIP: table {table} does not exist.")
            continue

        ttl_sql = f"""
        ALTER TABLE {table}
        MODIFY TTL {date_column} + INTERVAL {retention_days} DAY DELETE
        """

        optimize_sql = f"""
        OPTIMIZE TABLE {table} FINAL
        """

        if DRY_RUN:
            print("DRY_RUN=true. Would execute:")
            print(ttl_sql)
            print(optimize_sql)
            continue

        print("Applying TTL...")
        print(clickhouse_query(ttl_sql))

        print("Optimizing table...")
        print(clickhouse_query(optimize_sql))

    print("\nClickHouse maintenance finished.")

if __name__ == "__main__":
    main()
