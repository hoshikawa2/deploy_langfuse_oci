import os
import time
import psycopg2
from psycopg2 import sql

def env(name, default=None):
    value = os.getenv(name, default)
    if value is None:
        raise RuntimeError(f"Missing required env var: {name}")
    return value

DRY_RUN = env("DRY_RUN", "true").lower() == "true"
BATCH_SIZE = int(env("BATCH_SIZE", "5000"))
SLEEP_SECONDS = float(env("SLEEP_SECONDS", "1"))
RULES_RAW = env("POSTGRES_RETENTION_RULES", "")

def parse_rules(raw: str):
    rules = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        table, date_column, retention_days = [x.strip() for x in line.split("|")]
        rules.append({
            "table": table,
            "date_column": date_column,
            "retention_days": int(retention_days),
        })
    return rules

def table_exists(cur, table_name):
    cur.execute("""
        SELECT EXISTS (
          SELECT 1
          FROM information_schema.tables
          WHERE table_schema = 'public'
            AND table_name = %s
        )
    """, (table_name,))
    return cur.fetchone()[0]

def column_exists(cur, table_name, column_name):
    cur.execute("""
        SELECT EXISTS (
          SELECT 1
          FROM information_schema.columns
          WHERE table_schema = 'public'
            AND table_name = %s
            AND column_name = %s
        )
    """, (table_name, column_name))
    return cur.fetchone()[0]

def count_old_rows(cur, table_name, date_column, retention_days):
    query = sql.SQL("""
        SELECT COUNT(*)
        FROM {table}
        WHERE {date_column} < NOW() - (%s || ' days')::interval
    """).format(
        table=sql.Identifier(table_name),
        date_column=sql.Identifier(date_column),
    )
    cur.execute(query, (str(retention_days),))
    return cur.fetchone()[0]

def delete_batch(cur, table_name, date_column, retention_days):
    query = sql.SQL("""
        DELETE FROM {table}
        WHERE ctid IN (
            SELECT ctid
            FROM {table}
            WHERE {date_column} < NOW() - (%s || ' days')::interval
            LIMIT %s
        )
    """).format(
        table=sql.Identifier(table_name),
        date_column=sql.Identifier(date_column),
    )
    cur.execute(query, (str(retention_days), BATCH_SIZE))
    return cur.rowcount

def main():
    rules = parse_rules(RULES_RAW)
    if not rules:
        print("No POSTGRES_RETENTION_RULES configured.")
        return

    conn = psycopg2.connect(
        host=env("POSTGRES_HOST"),
        port=env("POSTGRES_PORT", "5432"),
        dbname=env("POSTGRES_DB"),
        user=env("POSTGRES_USER"),
        password=env("POSTGRES_PASSWORD"),
        connect_timeout=10,
    )

    conn.autocommit = False

    try:
        with conn.cursor() as cur:
            for rule in rules:
                table = rule["table"]
                date_column = rule["date_column"]
                retention_days = rule["retention_days"]

                print(f"\nRule: table={table}, column={date_column}, retention={retention_days} days")

                if not table_exists(cur, table):
                    print(f"SKIP: table {table} does not exist.")
                    continue

                if not column_exists(cur, table, date_column):
                    print(f"SKIP: column {date_column} does not exist in {table}.")
                    continue

                total = count_old_rows(cur, table, date_column, retention_days)
                print(f"Rows eligible for cleanup: {total}")

                if DRY_RUN:
                    print("DRY_RUN=true. No rows deleted.")
                    conn.rollback()
                    continue

                deleted_total = 0
                while True:
                    deleted = delete_batch(cur, table, date_column, retention_days)
                    conn.commit()

                    deleted_total += deleted
                    print(f"Deleted batch={deleted}, total={deleted_total}")

                    if deleted == 0:
                        break

                    time.sleep(SLEEP_SECONDS)

        print("\nCleanup finished.")
    finally:
        conn.close()

if __name__ == "__main__":
    main()
