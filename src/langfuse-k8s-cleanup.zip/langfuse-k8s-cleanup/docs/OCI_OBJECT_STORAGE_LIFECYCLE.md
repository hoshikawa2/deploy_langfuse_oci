# OCI Object Storage Lifecycle para Langfuse

Use lifecycle policy no bucket usado pelo Langfuse para controlar crescimento de blobs, payloads e arquivos arquivados.

## Estratégia recomendada

| Camada | Política |
|---|---|
| Hot | manter 15 a 30 dias |
| Archive | mover para Archive Storage após 30 a 60 dias |
| Delete | apagar após 90 a 180 dias |

## Exemplo conceitual

1. Criar bucket para Langfuse
2. Configurar Langfuse para usar OCI Object Storage
3. Criar lifecycle rule:
   - prefixo: `langfuse/`
   - ação: archive após 30 dias
   - ação: delete após 180 dias

## Atenção

Se existir obrigação de auditoria, não apague objetos antes de validar compliance.
