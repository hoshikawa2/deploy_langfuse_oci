# Operação do Cleanup

## 1. Validar modo seguro

O projeto começa com:

```yaml
DRY_RUN: "true"
```

Nesse modo, os jobs apenas mostram quantas linhas seriam removidas.

---

## 2. Rodar um job manualmente

```bash
kubectl create job \
  --from=cronjob/langfuse-postgres-cleanup \
  langfuse-postgres-cleanup-manual \
  -n langfuse-management
```

Ver logs:

```bash
kubectl logs -n langfuse-management job/langfuse-postgres-cleanup-manual
```

---

## 3. Ativar cleanup real

Edite:

```yaml
DRY_RUN: "false"
```

Aplique:

```bash
kubectl apply -k k8s/base
```

---

## 4. Verificar tamanho do banco

Entre no PostgreSQL e rode:

```sql
SELECT pg_size_pretty(pg_database_size(current_database()));
```

Maiores tabelas:

```sql
SELECT
  relname,
  pg_size_pretty(pg_total_relation_size(relid)) AS total_size
FROM pg_catalog.pg_statio_user_tables
ORDER BY pg_total_relation_size(relid) DESC
LIMIT 20;
```

Dead tuples:

```sql
SELECT
  relname,
  n_dead_tup,
  n_live_tup,
  last_vacuum,
  last_autovacuum
FROM pg_stat_user_tables
ORDER BY n_dead_tup DESC
LIMIT 20;
```

---

## 5. Vacuum

Após deletes grandes:

```sql
VACUUM ANALYZE;
```

Evite `VACUUM FULL` em produção sem janela de manutenção, porque pode bloquear e exigir espaço extra.

---

## 6. Checklist antes de produção

- [ ] Backup validado
- [ ] DRY_RUN validado
- [ ] Tabelas conferidas
- [ ] Retenção aprovada
- [ ] PVC com folga
- [ ] Autovacuum ativo
- [ ] Monitoramento de WAL
- [ ] ClickHouse com TTL
- [ ] Object Storage com lifecycle
