# Operação Redis

## Verificar memória

```bash
redis-cli INFO memory
```

---

## Verificar eviction

```bash
redis-cli INFO stats
```

Observe:

- evicted_keys
- expired_keys

---

## Verificar chaves sem TTL

```bash
redis-cli --scan | while read key; do
  ttl=$(redis-cli ttl "$key")
  if [ "$ttl" -eq -1 ]; then
    echo "$key"
  fi
done
```

---

# Configuração recomendada

```conf
maxmemory 4gb
maxmemory-policy allkeys-lru
appendonly no
```

---

# Se usar AOF

Monitore:

- crescimento de disco
- reescrita AOF
- IO

---

# Estratégia recomendada para LangGraph

## Redis deve guardar somente:

- checkpoints leves
- estado transitório
- cache temporário
- filas

## NÃO guardar:

- mensagens completas
- prompts gigantes
- PDFs
- chunks completos
- traces permanentes
