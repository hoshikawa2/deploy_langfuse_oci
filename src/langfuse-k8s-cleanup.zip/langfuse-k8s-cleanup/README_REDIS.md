# Extensão Redis para o Projeto Langfuse Kubernetes Management

Esta extensão adiciona:

- monitoramento Redis
- cleanup lógico de chaves
- análise de memória
- detecção de eviction
- validação de TTL
- políticas de proteção para ambientes LangGraph/Agents

---

# Objetivo

Evitar:

- OOMKilled
- crescimento infinito de memória
- explosão de chaves
- filas presas
- Redis eviction
- crescimento de AOF/RDB

---

# Principais verificações

## Memória

- used_memory
- used_memory_human
- mem_fragmentation_ratio

## Chaves

- quantidade total
- chaves sem TTL
- keys por prefixo

## Eviction

- evicted_keys

## Expiração

- expired_keys

---

# Estratégia recomendada

| Tipo | TTL |
|---|---|
| session state | 1h |
| streaming state | 5m |
| temporary workflow | 15m |
| retry queue | 30m |
| cache embeddings | 1d |

---

# Muito importante

NÃO salvar no Redis:

- histórico completo
- PDFs
- chunks RAG completos
- estado inteiro LangGraph
- prompts gigantes

Use:
- PostgreSQL
- ClickHouse
- OCI Object Storage

para payloads persistentes/pesados.
