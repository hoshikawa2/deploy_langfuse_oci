# Projeto Kubernetes de Gerenciamento e Cleanup do Langfuse

Este projeto cria uma camada operacional para manter o Langfuse saudável em Kubernetes/OKE, com foco em:

- limpeza controlada do PostgreSQL
- limpeza/TTL no ClickHouse
- monitoramento de crescimento de PVC
- execução via Kubernetes CronJob
- configuração por ConfigMap e Secret
- separação entre manifests base e overlay para OCI/OKE

> Observação: os nomes exatos das tabelas podem variar conforme a versão do Langfuse. Por isso, o projeto usa uma lista configurável de tabelas e colunas no ConfigMap.

---

## Arquitetura

```text
Langfuse
  ├── PostgreSQL
  │     └── CronJob de cleanup em batches
  │
  ├── ClickHouse
  │     └── CronJob para aplicar TTL / otimização
  │
  ├── PVCs
  │     └── CronJob de verificação de uso
  │
  └── OCI Object Storage
        └── lifecycle policy fora do cluster
```

---

## Estrutura

```text
langfuse-k8s-management/
├── k8s/
│   ├── base/
│   │   ├── namespace.yaml
│   │   ├── configmap-cleanup.yaml
│   │   ├── secret-cleanup.example.yaml
│   │   ├── postgres-cleanup-cronjob.yaml
│   │   ├── clickhouse-maintenance-cronjob.yaml
│   │   ├── pvc-monitor-cronjob.yaml
│   │   ├── rbac.yaml
│   │   └── kustomization.yaml
│   └── overlays/
│       └── oke/
│           ├── kustomization.yaml
│           └── patch-schedules.yaml
├── scripts/
│   ├── postgres/
│   │   └── cleanup_postgres.py
│   ├── clickhouse/
│   │   └── clickhouse_maintenance.py
│   └── monitoring/
│       └── pvc_usage_check.sh
└── docs/
    ├── OPERACAO.md
    └── OCI_OBJECT_STORAGE_LIFECYCLE.md
```

---

## Como aplicar

### 1. Crie o namespace e os recursos

```bash
kubectl apply -k k8s/base
```

Ou usando overlay OKE:

```bash
kubectl apply -k k8s/overlays/oke
```

---

## Secret

Copie o arquivo de exemplo:

```bash
cp k8s/base/secret-cleanup.example.yaml k8s/base/secret-cleanup.yaml
```

Edite os valores:

```yaml
POSTGRES_HOST: "langfuse-postgresql.langfuse.svc.cluster.local"
POSTGRES_DB: "langfuse"
POSTGRES_USER: "postgres"
POSTGRES_PASSWORD: "sua-senha"

CLICKHOUSE_HOST: "langfuse-clickhouse.langfuse.svc.cluster.local"
CLICKHOUSE_USER: "default"
CLICKHOUSE_PASSWORD: "sua-senha"
```

---

## Política inicial recomendada

Para ambiente de testes ou homologação:

| Dado | Retenção |
|---|---:|
| traces/spans detalhados | 15 dias |
| events/observations | 15 dias |
| scores | 30 dias |
| sessions | 60 dias |
| logs técnicos | 7 dias |

Para produção, ajuste conforme compliance e necessidade de auditoria.

---

## Segurança

Este projeto não apaga dados sem configuração explícita.

Antes de ativar em produção:

1. Rode em modo `DRY_RUN=true`
2. Confira as tabelas configuradas
3. Faça backup do PostgreSQL
4. Valide queries em ambiente de homologação
5. Ative `DRY_RUN=false`
